import TrainingDetailsE from "./TrainingDetailsE";
export default TrainingDetailsE;

