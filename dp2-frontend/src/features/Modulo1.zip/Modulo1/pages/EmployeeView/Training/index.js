import TrainingE from "./TrainingE";
export default TrainingE;

