import AddCourse from "./AddCourse";
export default AddCourse;