import ViewLearningPath from "./LearningPathDetails";
export default ViewLearningPath;