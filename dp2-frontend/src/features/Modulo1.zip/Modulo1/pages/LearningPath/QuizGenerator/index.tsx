import React from 'react';
import QuizGenerator from './QuizGenerator';
export default QuizGenerator;