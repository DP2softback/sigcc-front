import LearningPath from "./LearningPath";
export default LearningPath;