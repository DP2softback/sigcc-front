import LearningPathAssignment from "./Assignment"
export default LearningPathAssignment;