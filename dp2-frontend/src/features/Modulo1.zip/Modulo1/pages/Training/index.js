import Training from "./Training";
export default Training;

