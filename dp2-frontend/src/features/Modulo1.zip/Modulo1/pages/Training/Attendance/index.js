import TrainingAttendance from "./TrainingAttendance";
export default TrainingAttendance;