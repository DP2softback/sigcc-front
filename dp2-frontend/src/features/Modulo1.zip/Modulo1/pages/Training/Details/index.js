import TrainingDetails from "./TrainingDetails";
export default TrainingDetails;

