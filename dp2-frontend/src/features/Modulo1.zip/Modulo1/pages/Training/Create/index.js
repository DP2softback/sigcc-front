import TrainingCreate from "./TrainingCreate";
export default TrainingCreate;

