import TrainingAssignment from "./TrainingAssignment";
export default TrainingAssignment;
