import './content/common.css';
import LearningPath from "./pages/LearningPath/LearningPath";
export default LearningPath;