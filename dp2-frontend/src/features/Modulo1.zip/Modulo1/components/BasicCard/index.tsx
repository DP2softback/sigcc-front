import BasicCard from './BasicCard';
export default BasicCard;