export type Props = {

}
export type State = {
    previewVideo: any
}