import BasicCard2 from './BasicCard2';
export default BasicCard2;