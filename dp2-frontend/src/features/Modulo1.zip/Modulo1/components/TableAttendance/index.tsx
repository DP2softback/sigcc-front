import TableAttendance from './TableAttendance';
export default TableAttendance;
