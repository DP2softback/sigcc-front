import Rate from "./Rate";
export default Rate