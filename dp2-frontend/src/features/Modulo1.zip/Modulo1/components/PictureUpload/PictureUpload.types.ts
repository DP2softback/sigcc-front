export type Props = {

}
export type State = {
    previewImage: any
}