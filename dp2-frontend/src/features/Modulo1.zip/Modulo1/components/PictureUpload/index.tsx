import PictureUpload from "./PictureUpload";
export default PictureUpload;